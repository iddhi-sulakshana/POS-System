﻿using System;
using System.Drawing;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using System.IO;
using System.Globalization;

namespace Point_Of_Sale
{
    public partial class Form_Preview_Sale : KryptonForm
    {
        // used for change currency for rupees
        readonly CultureInfo Lanka = new CultureInfo("si-LK");

        public Form_Preview_Sale()
        {
            InitializeComponent();
        }

        readonly Class_Sale Sales = new Class_Sale();

        // store sale details
        SaleStruct SaleDetails = new SaleStruct();

        // give sale id from the other classes
        public int SalesId;

        // load company and sale details if id is greater than 0
        private void Form_Preview_Sale_Load(object sender, EventArgs e)
        {
            if(SalesId > 0)
            {
                Load_Company_Details();
                Load_Sale_Details();
            }
            else
            {
                Clear_Preview();
                this.Close();
            }
        }

        // load company details using text file in the document folder
        private void Load_Company_Details()
        {
            try
            {
                string UserPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "PointOfSale");
                string[] Lines = File.ReadAllLines(Path.Combine(UserPath, "Company.txt"));
                Lbl_CompanyName.Text = Lines[0];
                Lbl_Email.Text = Lines[2];
                Lbl_Phone.Text = Lines[3];
                Lbl_Address.Text = Lines[1];
                Picture_CompanyLogo.Image = Image.FromFile(Path.Combine(UserPath, "Logo.png"));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Clear_Preview();
                this.Close();
            }
        }

        // load sale details from the database
        private void Load_Sale_Details()
        {
            SaleDetails = Sales.Load_Sale_Details(SalesId);
            Class_Customer Customers = new Class_Customer();
            Lbl_Customer.Text = $"Bill To : {Customers.Get_Customer_Name(SaleDetails.Customer)}";
            Lbl_SaleId.Text = $"Sale : #{SaleDetails.Id}";
            Lbl_Date.Text = $"Date : {SaleDetails.Date.ToString("MM/dd/yyyy hh:mm:ss tt")}";
            Lbl_Total_Value.Text = string.Format(Lanka, "{0:c}", ((SaleDetails.Subtotal / (100 - SaleDetails.Discount)) * 100));
            Lbl_Discount_Value.Text = (SaleDetails.Discount / 100).ToString("P02");
            Lbl_Subtotal_Value.Text = string.Format(Lanka, "{0:c}", SaleDetails.Subtotal);
            foreach(ProductStruct Product in SaleDetails.Products)
            {
                Insert_Preview_Item(Product.Id, Product.Name, Product.Unit, Product.Price);
            }
        }

        /// insert product to the item loader panel by using id, name, 
        /// quantity and price as parameters
        private void Insert_Preview_Item(int Id, string Name, int Quantity, double Price)
        {
            // Create Label Name
            Label LblName = new Label();
            LblName.Name = $"Preview_Label_Name_{Id}";
            LblName.Text = Name;
            LblName.Dock = DockStyle.Fill;
            LblName.TextAlign = ContentAlignment.MiddleLeft;
            LblName.ForeColor = Color.White;
            // Create Label Quantity 
            Label LblQuantity = new Label();
            LblQuantity.Name = $"Preview_Label_Quantity_{Id}";
            LblQuantity.Text = Quantity.ToString();
            LblQuantity.Dock = DockStyle.Fill;
            LblQuantity.TextAlign = ContentAlignment.MiddleCenter;
            LblQuantity.ForeColor = Color.White;
            // Create Label Price 
            Label LblPrice = new Label();
            LblPrice.Name = $"Preview_Label_Price_{Id}";
            LblPrice.Text = Math.Round(Price, 2).ToString("0.00");
            LblPrice.Dock = DockStyle.Fill;
            LblPrice.TextAlign = ContentAlignment.MiddleRight;
            LblPrice.ForeColor = Color.White;
            // Create Label Amount 
            Label LblAmount = new Label();
            LblAmount.Name = $"Preview_Label_Amount_{Id}";
            LblAmount.Text = Math.Round(Price * Quantity, 2).ToString("0.00");
            LblAmount.Dock = DockStyle.Fill;
            LblAmount.TextAlign = ContentAlignment.MiddleRight;
            LblAmount.ForeColor = Color.White;

            //Create Table Panel
            TableLayoutPanel Table = new TableLayoutPanel();
            Table.Name = $"Table_Product_Details_{Id}";
            Table.Height = 40;
            Table.Dock = DockStyle.Top;
            Table.RowCount = 1;
            Table.ColumnCount = 4;
            Table.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            Table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 35F));
            Table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 15F));
            Table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            Table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            Table.Controls.Add(LblName, 0, 0);
            Table.Controls.Add(LblQuantity, 1, 0);
            Table.Controls.Add(LblPrice, 2, 0);
            Table.Controls.Add(LblAmount, 3, 0);

            // Insert to Form
            Panel_Item_Loader.Controls.Add(Table);
            Panel_Item_Loader.Controls.SetChildIndex(Table, 0);
        }
        
        // clear all the details from the form
        private void Clear_Preview()
        {
            SalesId = -1;
            Panel_Item_Loader.Controls.Clear();
            Lbl_Customer.Text = "";
            Lbl_SaleId.Text = "";
            Lbl_Date.Text = "";
            Lbl_Total_Value.Text = "";
            Lbl_Discount_Value.Text = "";
            Lbl_Subtotal_Value.Text = "";
        }

        // close the form
        private void Btn_Cancel_Click(object sender, EventArgs e)
        {
            Clear_Preview();
            this.Close();
        }

        // generate printable pdf based on the sales details and open
        private void Btn_Print_Click(object sender, EventArgs e)
        {
            Btn_Print.Enabled = false;
            Class_Print_Sale Print = new Class_Print_Sale();
            Print.Print_Sale(SaleDetails);
            Btn_Print.Enabled = true;
            Clear_Preview();
            this.Close();
        }
    }
}
