﻿namespace Point_Of_Sale
{
    partial class Form_NumberPad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.Btn_NumDot = new System.Windows.Forms.Button();
            this.Btn_Num0 = new System.Windows.Forms.Button();
            this.Btn_Submit = new System.Windows.Forms.Button();
            this.Btn_Num9 = new System.Windows.Forms.Button();
            this.Btn_Num8 = new System.Windows.Forms.Button();
            this.Btn_Num7 = new System.Windows.Forms.Button();
            this.Btn_Escape = new System.Windows.Forms.Button();
            this.Btn_Num6 = new System.Windows.Forms.Button();
            this.Btn_Num5 = new System.Windows.Forms.Button();
            this.Btn_Num4 = new System.Windows.Forms.Button();
            this.Btn_Back = new System.Windows.Forms.Button();
            this.Btn_Num3 = new System.Windows.Forms.Button();
            this.Btn_Num2 = new System.Windows.Forms.Button();
            this.Txt_Value = new System.Windows.Forms.TextBox();
            this.Btn_Num1 = new System.Windows.Forms.Button();
            this.kryptonPalette1 = new ComponentFactory.Krypton.Toolkit.KryptonPalette(this.components);
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Controls.Add(this.Btn_NumDot, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.Btn_Num0, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.Btn_Submit, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.Btn_Num9, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.Btn_Num8, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.Btn_Num7, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.Btn_Escape, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.Btn_Num6, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.Btn_Num5, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.Btn_Num4, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.Btn_Back, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.Btn_Num3, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.Btn_Num2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.Txt_Value, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.Btn_Num1, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(7, 7);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(290, 377);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // Btn_NumDot
            // 
            this.Btn_NumDot.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Btn_NumDot.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.Btn_NumDot.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_NumDot.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_NumDot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_NumDot.Font = new System.Drawing.Font("Arial Black", 35F);
            this.Btn_NumDot.Location = new System.Drawing.Point(147, 303);
            this.Btn_NumDot.Name = "Btn_NumDot";
            this.Btn_NumDot.Size = new System.Drawing.Size(66, 71);
            this.Btn_NumDot.TabIndex = 15;
            this.Btn_NumDot.Text = ".";
            this.Btn_NumDot.UseVisualStyleBackColor = true;
            this.Btn_NumDot.Click += new System.EventHandler(this.Number_Pad_Click);
            // 
            // Btn_Num0
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.Btn_Num0, 2);
            this.Btn_Num0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Btn_Num0.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.Btn_Num0.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Num0.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Num0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Num0.Font = new System.Drawing.Font("Arial Black", 35F);
            this.Btn_Num0.Location = new System.Drawing.Point(3, 303);
            this.Btn_Num0.Name = "Btn_Num0";
            this.Btn_Num0.Size = new System.Drawing.Size(138, 71);
            this.Btn_Num0.TabIndex = 13;
            this.Btn_Num0.Text = "0";
            this.Btn_Num0.UseVisualStyleBackColor = true;
            this.Btn_Num0.Click += new System.EventHandler(this.Number_Pad_Click);
            // 
            // Btn_Submit
            // 
            this.Btn_Submit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Btn_Submit.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.Btn_Submit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Submit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Submit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Submit.Font = new System.Drawing.Font("Arial Black", 35F);
            this.Btn_Submit.Image = global::Point_Of_Sale.Properties.Resources.enter;
            this.Btn_Submit.Location = new System.Drawing.Point(219, 228);
            this.Btn_Submit.Name = "Btn_Submit";
            this.tableLayoutPanel1.SetRowSpan(this.Btn_Submit, 2);
            this.Btn_Submit.Size = new System.Drawing.Size(68, 146);
            this.Btn_Submit.TabIndex = 12;
            this.Btn_Submit.UseVisualStyleBackColor = true;
            this.Btn_Submit.Click += new System.EventHandler(this.Btn_Submit_Click);
            // 
            // Btn_Num9
            // 
            this.Btn_Num9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Btn_Num9.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.Btn_Num9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Num9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Num9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Num9.Font = new System.Drawing.Font("Arial Black", 35F);
            this.Btn_Num9.Location = new System.Drawing.Point(147, 228);
            this.Btn_Num9.Name = "Btn_Num9";
            this.Btn_Num9.Size = new System.Drawing.Size(66, 69);
            this.Btn_Num9.TabIndex = 11;
            this.Btn_Num9.Text = "9";
            this.Btn_Num9.UseVisualStyleBackColor = true;
            this.Btn_Num9.Click += new System.EventHandler(this.Number_Pad_Click);
            // 
            // Btn_Num8
            // 
            this.Btn_Num8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Btn_Num8.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.Btn_Num8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Num8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Num8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Num8.Font = new System.Drawing.Font("Arial Black", 35F);
            this.Btn_Num8.Location = new System.Drawing.Point(75, 228);
            this.Btn_Num8.Name = "Btn_Num8";
            this.Btn_Num8.Size = new System.Drawing.Size(66, 69);
            this.Btn_Num8.TabIndex = 10;
            this.Btn_Num8.Text = "8";
            this.Btn_Num8.UseVisualStyleBackColor = true;
            this.Btn_Num8.Click += new System.EventHandler(this.Number_Pad_Click);
            // 
            // Btn_Num7
            // 
            this.Btn_Num7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Btn_Num7.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.Btn_Num7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Num7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Num7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Num7.Font = new System.Drawing.Font("Arial Black", 35F);
            this.Btn_Num7.Location = new System.Drawing.Point(3, 228);
            this.Btn_Num7.Name = "Btn_Num7";
            this.Btn_Num7.Size = new System.Drawing.Size(66, 69);
            this.Btn_Num7.TabIndex = 9;
            this.Btn_Num7.Text = "7";
            this.Btn_Num7.UseVisualStyleBackColor = true;
            this.Btn_Num7.Click += new System.EventHandler(this.Number_Pad_Click);
            // 
            // Btn_Escape
            // 
            this.Btn_Escape.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Btn_Escape.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.Btn_Escape.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Escape.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Escape.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Escape.Font = new System.Drawing.Font("Bahnschrift Light Condensed", 20F);
            this.Btn_Escape.Location = new System.Drawing.Point(219, 153);
            this.Btn_Escape.Name = "Btn_Escape";
            this.Btn_Escape.Size = new System.Drawing.Size(68, 69);
            this.Btn_Escape.TabIndex = 8;
            this.Btn_Escape.Text = "esc";
            this.Btn_Escape.UseVisualStyleBackColor = true;
            this.Btn_Escape.Click += new System.EventHandler(this.Btn_Escape_Click);
            // 
            // Btn_Num6
            // 
            this.Btn_Num6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Btn_Num6.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.Btn_Num6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Num6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Num6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Num6.Font = new System.Drawing.Font("Arial Black", 35F);
            this.Btn_Num6.Location = new System.Drawing.Point(147, 153);
            this.Btn_Num6.Name = "Btn_Num6";
            this.Btn_Num6.Size = new System.Drawing.Size(66, 69);
            this.Btn_Num6.TabIndex = 7;
            this.Btn_Num6.Text = "6";
            this.Btn_Num6.UseVisualStyleBackColor = true;
            this.Btn_Num6.Click += new System.EventHandler(this.Number_Pad_Click);
            // 
            // Btn_Num5
            // 
            this.Btn_Num5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Btn_Num5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.Btn_Num5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Num5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Num5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Num5.Font = new System.Drawing.Font("Arial Black", 35F);
            this.Btn_Num5.Location = new System.Drawing.Point(75, 153);
            this.Btn_Num5.Name = "Btn_Num5";
            this.Btn_Num5.Size = new System.Drawing.Size(66, 69);
            this.Btn_Num5.TabIndex = 6;
            this.Btn_Num5.Text = "5";
            this.Btn_Num5.UseVisualStyleBackColor = true;
            this.Btn_Num5.Click += new System.EventHandler(this.Number_Pad_Click);
            // 
            // Btn_Num4
            // 
            this.Btn_Num4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Btn_Num4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.Btn_Num4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Num4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Num4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Num4.Font = new System.Drawing.Font("Arial Black", 35F);
            this.Btn_Num4.Location = new System.Drawing.Point(3, 153);
            this.Btn_Num4.Name = "Btn_Num4";
            this.Btn_Num4.Size = new System.Drawing.Size(66, 69);
            this.Btn_Num4.TabIndex = 5;
            this.Btn_Num4.Text = "4";
            this.Btn_Num4.UseVisualStyleBackColor = true;
            this.Btn_Num4.Click += new System.EventHandler(this.Number_Pad_Click);
            // 
            // Btn_Back
            // 
            this.Btn_Back.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Btn_Back.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Btn_Back.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.Btn_Back.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Back.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Back.Font = new System.Drawing.Font("Arial Black", 35F);
            this.Btn_Back.Image = global::Point_Of_Sale.Properties.Resources.backspace;
            this.Btn_Back.Location = new System.Drawing.Point(219, 78);
            this.Btn_Back.Name = "Btn_Back";
            this.Btn_Back.Size = new System.Drawing.Size(68, 69);
            this.Btn_Back.TabIndex = 4;
            this.Btn_Back.UseVisualStyleBackColor = true;
            this.Btn_Back.Click += new System.EventHandler(this.Btn_Back_Click);
            // 
            // Btn_Num3
            // 
            this.Btn_Num3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Btn_Num3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.Btn_Num3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Num3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Num3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Num3.Font = new System.Drawing.Font("Arial Black", 35F);
            this.Btn_Num3.Location = new System.Drawing.Point(147, 78);
            this.Btn_Num3.Name = "Btn_Num3";
            this.Btn_Num3.Size = new System.Drawing.Size(66, 69);
            this.Btn_Num3.TabIndex = 3;
            this.Btn_Num3.Text = "3";
            this.Btn_Num3.UseVisualStyleBackColor = true;
            this.Btn_Num3.Click += new System.EventHandler(this.Number_Pad_Click);
            // 
            // Btn_Num2
            // 
            this.Btn_Num2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Btn_Num2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.Btn_Num2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Num2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Num2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Num2.Font = new System.Drawing.Font("Arial Black", 35F);
            this.Btn_Num2.Location = new System.Drawing.Point(75, 78);
            this.Btn_Num2.Name = "Btn_Num2";
            this.Btn_Num2.Size = new System.Drawing.Size(66, 69);
            this.Btn_Num2.TabIndex = 2;
            this.Btn_Num2.Text = "2";
            this.Btn_Num2.UseVisualStyleBackColor = true;
            this.Btn_Num2.Click += new System.EventHandler(this.Number_Pad_Click);
            // 
            // Txt_Value
            // 
            this.Txt_Value.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.Txt_Value.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tableLayoutPanel1.SetColumnSpan(this.Txt_Value, 4);
            this.Txt_Value.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Txt_Value.Font = new System.Drawing.Font("Arial Black", 35F);
            this.Txt_Value.ForeColor = System.Drawing.Color.White;
            this.Txt_Value.Location = new System.Drawing.Point(3, 3);
            this.Txt_Value.Name = "Txt_Value";
            this.Txt_Value.Size = new System.Drawing.Size(284, 73);
            this.Txt_Value.TabIndex = 0;
            this.Txt_Value.Text = "1";
            this.Txt_Value.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Txt_Value.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txt_Value_KeyPress);
            // 
            // Btn_Num1
            // 
            this.Btn_Num1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Btn_Num1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.Btn_Num1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Num1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(200)))));
            this.Btn_Num1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Num1.Font = new System.Drawing.Font("Arial Black", 35F);
            this.Btn_Num1.Location = new System.Drawing.Point(3, 78);
            this.Btn_Num1.Name = "Btn_Num1";
            this.Btn_Num1.Size = new System.Drawing.Size(66, 69);
            this.Btn_Num1.TabIndex = 1;
            this.Btn_Num1.Text = "1";
            this.Btn_Num1.UseVisualStyleBackColor = true;
            this.Btn_Num1.Click += new System.EventHandler(this.Number_Pad_Click);
            // 
            // kryptonPalette1
            // 
            this.kryptonPalette1.BasePaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Black;
            this.kryptonPalette1.ButtonSpecs.FormClose.Image = global::Point_Of_Sale.Properties.Resources.headerclose;
            this.kryptonPalette1.ButtonSpecs.FormMax.Image = global::Point_Of_Sale.Properties.Resources.headermax;
            this.kryptonPalette1.ButtonSpecs.FormMin.Image = global::Point_Of_Sale.Properties.Resources.headermin;
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Border.Rounding = 10;
            this.kryptonPalette1.HeaderStyles.HeaderForm.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(41)))));
            this.kryptonPalette1.HeaderStyles.HeaderForm.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.kryptonPalette1.HeaderStyles.HeaderForm.StateCommon.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.kryptonPalette1.HeaderStyles.HeaderForm.StateCommon.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.kryptonPalette1.HeaderStyles.HeaderForm.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.HeaderStyles.HeaderForm.StateCommon.Content.Padding = new System.Windows.Forms.Padding(10, -1, -1, -1);
            // 
            // Form_NumberPad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.ClientSize = new System.Drawing.Size(304, 391);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12.5F);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form_NumberPad";
            this.Opacity = 0.95D;
            this.Padding = new System.Windows.Forms.Padding(7);
            this.Palette = this.kryptonPalette1;
            this.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "NumberPad";
            this.TopMost = true;
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button Btn_NumDot;
        private System.Windows.Forms.Button Btn_Num0;
        private System.Windows.Forms.Button Btn_Submit;
        private System.Windows.Forms.Button Btn_Num9;
        private System.Windows.Forms.Button Btn_Num8;
        private System.Windows.Forms.Button Btn_Num7;
        private System.Windows.Forms.Button Btn_Escape;
        private System.Windows.Forms.Button Btn_Num6;
        private System.Windows.Forms.Button Btn_Num5;
        private System.Windows.Forms.Button Btn_Num4;
        private System.Windows.Forms.Button Btn_Back;
        private System.Windows.Forms.Button Btn_Num3;
        private System.Windows.Forms.Button Btn_Num2;
        private System.Windows.Forms.Button Btn_Num1;
        private ComponentFactory.Krypton.Toolkit.KryptonPalette kryptonPalette1;
        public System.Windows.Forms.TextBox Txt_Value;
    }
}