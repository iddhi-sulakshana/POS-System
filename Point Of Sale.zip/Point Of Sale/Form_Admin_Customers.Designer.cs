﻿namespace Point_Of_Sale
{
    partial class Form_Admin_Customers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_Customer_Add = new System.Windows.Forms.Button();
            this.Btn_Customer_Edit = new System.Windows.Forms.Button();
            this.Btn_Customer_Delete = new System.Windows.Forms.Button();
            this.Panel__Header = new System.Windows.Forms.TableLayoutPanel();
            this.Lbl_Customer_Header = new System.Windows.Forms.Label();
            this.Panel_Customer_Content = new System.Windows.Forms.Panel();
            this.Panel_Customer_Loader = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Panel_Customer_Header = new System.Windows.Forms.TableLayoutPanel();
            this.Lbl_Phone_Header_Phone = new System.Windows.Forms.Label();
            this.Lbl_Customer_Header_Address = new System.Windows.Forms.Label();
            this.Lbl_Customer_Header_Name = new System.Windows.Forms.Label();
            this.Panel__Header.SuspendLayout();
            this.Panel_Customer_Content.SuspendLayout();
            this.panel2.SuspendLayout();
            this.Panel_Customer_Header.SuspendLayout();
            this.SuspendLayout();
            // 
            // Btn_Customer_Add
            // 
            this.Btn_Customer_Add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(160)))), ((int)(((byte)(0)))));
            this.Btn_Customer_Add.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.Btn_Customer_Add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Customer_Add.Font = new System.Drawing.Font("Arial Black", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Customer_Add.ForeColor = System.Drawing.Color.White;
            this.Btn_Customer_Add.Location = new System.Drawing.Point(11, 587);
            this.Btn_Customer_Add.Name = "Btn_Customer_Add";
            this.Btn_Customer_Add.Size = new System.Drawing.Size(229, 75);
            this.Btn_Customer_Add.TabIndex = 11;
            this.Btn_Customer_Add.Text = "Add";
            this.Btn_Customer_Add.UseVisualStyleBackColor = false;
            this.Btn_Customer_Add.Click += new System.EventHandler(this.Btn_Customer_Add_Click);
            // 
            // Btn_Customer_Edit
            // 
            this.Btn_Customer_Edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.Btn_Customer_Edit.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.Btn_Customer_Edit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Customer_Edit.Font = new System.Drawing.Font("Arial Black", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Customer_Edit.ForeColor = System.Drawing.Color.White;
            this.Btn_Customer_Edit.Location = new System.Drawing.Point(399, 587);
            this.Btn_Customer_Edit.Name = "Btn_Customer_Edit";
            this.Btn_Customer_Edit.Size = new System.Drawing.Size(229, 75);
            this.Btn_Customer_Edit.TabIndex = 13;
            this.Btn_Customer_Edit.Text = "Edit";
            this.Btn_Customer_Edit.UseVisualStyleBackColor = false;
            this.Btn_Customer_Edit.Click += new System.EventHandler(this.Btn_Customer_Edit_Click);
            // 
            // Btn_Customer_Delete
            // 
            this.Btn_Customer_Delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Btn_Customer_Delete.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.Btn_Customer_Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Customer_Delete.Font = new System.Drawing.Font("Arial Black", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Customer_Delete.ForeColor = System.Drawing.Color.White;
            this.Btn_Customer_Delete.Location = new System.Drawing.Point(788, 587);
            this.Btn_Customer_Delete.Name = "Btn_Customer_Delete";
            this.Btn_Customer_Delete.Size = new System.Drawing.Size(229, 75);
            this.Btn_Customer_Delete.TabIndex = 14;
            this.Btn_Customer_Delete.Text = "Delete";
            this.Btn_Customer_Delete.UseVisualStyleBackColor = false;
            this.Btn_Customer_Delete.Click += new System.EventHandler(this.Btn_Customer_Delete_Click);
            // 
            // Panel__Header
            // 
            this.Panel__Header.ColumnCount = 1;
            this.Panel__Header.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.Panel__Header.Controls.Add(this.Lbl_Customer_Header, 0, 0);
            this.Panel__Header.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel__Header.Location = new System.Drawing.Point(0, 0);
            this.Panel__Header.Name = "Panel__Header";
            this.Panel__Header.RowCount = 1;
            this.Panel__Header.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.Panel__Header.Size = new System.Drawing.Size(1022, 47);
            this.Panel__Header.TabIndex = 15;
            // 
            // Lbl_Customer_Header
            // 
            this.Lbl_Customer_Header.AutoSize = true;
            this.Lbl_Customer_Header.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Lbl_Customer_Header.Font = new System.Drawing.Font("Microsoft YaHei", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Customer_Header.Location = new System.Drawing.Point(3, 0);
            this.Lbl_Customer_Header.Name = "Lbl_Customer_Header";
            this.Lbl_Customer_Header.Size = new System.Drawing.Size(1016, 47);
            this.Lbl_Customer_Header.TabIndex = 0;
            this.Lbl_Customer_Header.Text = "Customers";
            this.Lbl_Customer_Header.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Panel_Customer_Content
            // 
            this.Panel_Customer_Content.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel_Customer_Content.Controls.Add(this.Panel_Customer_Loader);
            this.Panel_Customer_Content.Controls.Add(this.panel2);
            this.Panel_Customer_Content.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel_Customer_Content.Location = new System.Drawing.Point(0, 47);
            this.Panel_Customer_Content.Name = "Panel_Customer_Content";
            this.Panel_Customer_Content.Size = new System.Drawing.Size(1022, 534);
            this.Panel_Customer_Content.TabIndex = 16;
            // 
            // Panel_Customer_Loader
            // 
            this.Panel_Customer_Loader.AutoScroll = true;
            this.Panel_Customer_Loader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel_Customer_Loader.Location = new System.Drawing.Point(0, 52);
            this.Panel_Customer_Loader.Name = "Panel_Customer_Loader";
            this.Panel_Customer_Loader.Size = new System.Drawing.Size(1020, 480);
            this.Panel_Customer_Loader.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(41)))));
            this.panel2.Controls.Add(this.Panel_Customer_Header);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1020, 52);
            this.panel2.TabIndex = 0;
            // 
            // Panel_Customer_Header
            // 
            this.Panel_Customer_Header.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.Panel_Customer_Header.ColumnCount = 3;
            this.Panel_Customer_Header.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.Panel_Customer_Header.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45F));
            this.Panel_Customer_Header.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.Panel_Customer_Header.Controls.Add(this.Lbl_Phone_Header_Phone, 0, 0);
            this.Panel_Customer_Header.Controls.Add(this.Lbl_Customer_Header_Address, 0, 0);
            this.Panel_Customer_Header.Controls.Add(this.Lbl_Customer_Header_Name, 0, 0);
            this.Panel_Customer_Header.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel_Customer_Header.Location = new System.Drawing.Point(0, 0);
            this.Panel_Customer_Header.Name = "Panel_Customer_Header";
            this.Panel_Customer_Header.RowCount = 1;
            this.Panel_Customer_Header.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.Panel_Customer_Header.Size = new System.Drawing.Size(1020, 52);
            this.Panel_Customer_Header.TabIndex = 0;
            // 
            // Lbl_Phone_Header_Phone
            // 
            this.Lbl_Phone_Header_Phone.AutoSize = true;
            this.Lbl_Phone_Header_Phone.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Lbl_Phone_Header_Phone.Font = new System.Drawing.Font("Microsoft YaHei", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Phone_Header_Phone.Location = new System.Drawing.Point(767, 1);
            this.Lbl_Phone_Header_Phone.Name = "Lbl_Phone_Header_Phone";
            this.Lbl_Phone_Header_Phone.Size = new System.Drawing.Size(249, 50);
            this.Lbl_Phone_Header_Phone.TabIndex = 3;
            this.Lbl_Phone_Header_Phone.Text = "Phone";
            this.Lbl_Phone_Header_Phone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Lbl_Customer_Header_Address
            // 
            this.Lbl_Customer_Header_Address.AutoSize = true;
            this.Lbl_Customer_Header_Address.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Lbl_Customer_Header_Address.Font = new System.Drawing.Font("Microsoft YaHei", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Customer_Header_Address.Location = new System.Drawing.Point(309, 1);
            this.Lbl_Customer_Header_Address.Name = "Lbl_Customer_Header_Address";
            this.Lbl_Customer_Header_Address.Size = new System.Drawing.Size(451, 50);
            this.Lbl_Customer_Header_Address.TabIndex = 2;
            this.Lbl_Customer_Header_Address.Text = "Address";
            this.Lbl_Customer_Header_Address.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Lbl_Customer_Header_Name
            // 
            this.Lbl_Customer_Header_Name.AutoSize = true;
            this.Lbl_Customer_Header_Name.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Lbl_Customer_Header_Name.Font = new System.Drawing.Font("Microsoft YaHei", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Customer_Header_Name.Location = new System.Drawing.Point(4, 1);
            this.Lbl_Customer_Header_Name.Name = "Lbl_Customer_Header_Name";
            this.Lbl_Customer_Header_Name.Size = new System.Drawing.Size(298, 50);
            this.Lbl_Customer_Header_Name.TabIndex = 1;
            this.Lbl_Customer_Header_Name.Text = "Name";
            this.Lbl_Customer_Header_Name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form_Admin_Customers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.ClientSize = new System.Drawing.Size(1022, 666);
            this.Controls.Add(this.Panel_Customer_Content);
            this.Controls.Add(this.Btn_Customer_Delete);
            this.Controls.Add(this.Panel__Header);
            this.Controls.Add(this.Btn_Customer_Add);
            this.Controls.Add(this.Btn_Customer_Edit);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1022, 666);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1022, 666);
            this.Name = "Form_Admin_Customers";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form_Admin_Customers";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Form_Admin_Customers_Load);
            this.Panel__Header.ResumeLayout(false);
            this.Panel__Header.PerformLayout();
            this.Panel_Customer_Content.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.Panel_Customer_Header.ResumeLayout(false);
            this.Panel_Customer_Header.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button Btn_Customer_Add;
        private System.Windows.Forms.Button Btn_Customer_Edit;
        private System.Windows.Forms.Button Btn_Customer_Delete;
        private System.Windows.Forms.TableLayoutPanel Panel__Header;
        private System.Windows.Forms.Label Lbl_Customer_Header;
        private System.Windows.Forms.Panel Panel_Customer_Content;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel Panel_Customer_Header;
        private System.Windows.Forms.Label Lbl_Customer_Header_Address;
        private System.Windows.Forms.Label Lbl_Customer_Header_Name;
        private System.Windows.Forms.Label Lbl_Phone_Header_Phone;
        private System.Windows.Forms.Panel Panel_Customer_Loader;
    }
}