﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Point_Of_Sale
{
    public partial class Form_Admin_Users : Form
    {
        public Form_Admin_Users()
        {
            InitializeComponent();
        }

        readonly Class_User User = new Class_User();

        // used for get user inputs
        readonly Form_User_Input GetInput = new Form_User_Input();

        // store previously clicked panel and clicked id
        Panel PreviouslyClicked = new Panel();
        int Selected = -1;

        // load users to the user product loader
        private void Form_Admin_Users_Load(object sender, EventArgs e)
        {
            Update_User_List();
        }

        // insert user to the user product loader by using id, name, password as parameters
        private void Insert_User(int Number, string Name, string Password)
        {
            Panel ChildUser = new Panel();
            ChildUser.Name = $"Panel_User_{Number}";
            ChildUser.Dock = DockStyle.Top;
            ChildUser.Height = 50;
            Font font = new Font("Arial", 18);
            // Create Label Name
            Label LblName = new Label();
            LblName.Name = $"User_Label_Name_{Number}";
            LblName.Font = font;
            LblName.Text = Name;
            LblName.Dock = DockStyle.Fill;
            LblName.TextAlign = ContentAlignment.MiddleLeft;
            LblName.ForeColor = Color.White;
            LblName.Click += User_Label_Clicked;
            // Create TxtBox Password
            TextBox TxtPassword = new TextBox();
            TxtPassword.Name = $"User_Txt_Password_{Number}";
            TxtPassword.PasswordChar = '*';
            TxtPassword.Font = font;
            TxtPassword.Text = Password;
            TxtPassword.Dock = DockStyle.Fill;
            TxtPassword.BackColor = Color.FromArgb(51, 51, 51);
            TxtPassword.BorderStyle = BorderStyle.None;
            TxtPassword.ForeColor = Color.White;
            TxtPassword.ReadOnly = true;
            TxtPassword.TabStop = false;
            TxtPassword.Click += User_Label_Clicked;
            // Create Show Button 
            Button BtnShow = new Button();
            BtnShow.Name = $"User_Show_Btn_{Number}";
            BtnShow.BackgroundImage = new Bitmap(Properties.Resources.hide_eye);
            BtnShow.BackgroundImageLayout = ImageLayout.Zoom;
            BtnShow.Dock = DockStyle.Fill;
            BtnShow.TextAlign = ContentAlignment.MiddleCenter;
            BtnShow.ForeColor = Color.White;
            BtnShow.MouseDown += Show_Password;
            BtnShow.MouseUp += Hide_Password;

            //Create Table Panel
            TableLayoutPanel Table = new TableLayoutPanel();
            Table.Name = $"Table_User_Details_{Number}";
            Table.Dock = DockStyle.Fill;
            Table.RowCount = 1;
            Table.ColumnCount = 3;
            Table.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            Table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            Table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            Table.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 48));
            Table.Controls.Add(LblName, 0, 0);
            Table.Controls.Add(TxtPassword, 1, 0);
            Table.Controls.Add(BtnShow, 2, 0);

            // Insert to Main Panel
            ChildUser.Controls.Add(Table);
            Panel_User_Loader.Controls.Add(ChildUser);
            Panel_User_Loader.Controls.SetChildIndex(ChildUser, 0);
        }
        
        // show password when user click on the show password button
        private void Show_Password(object sender, MouseEventArgs e)
        {
            Button Clicked = sender as Button;
            Clicked.BackgroundImage = new Bitmap(Properties.Resources.show_eye);
            TextBox ClickedTextBox = Clicked.Parent.Controls[1] as TextBox;
            ClickedTextBox.PasswordChar = '\0';
        }

        // hide password when user release mouse click
        private void Hide_Password(object sender, MouseEventArgs e)
        {
            Button Clicked = sender as Button;
            Clicked.BackgroundImage = new Bitmap(Properties.Resources.hide_eye);
            TextBox ClickedTextBox = Clicked.Parent.Controls[1] as TextBox;
            ClickedTextBox.PasswordChar = '*';
        }

        // change clicked status to the current clicked label
        private void User_Label_Clicked(object sender, EventArgs e)
        {
            PreviouslyClicked.BackColor = Color.FromArgb(51, 51, 51);
            if (sender.GetType().Name == "Label")
            {
                Label Clicked = sender as Label;
                Selected = int.Parse(Clicked.Name.Split('_')[3]);
                Clicked.Parent.BackColor = Color.FromArgb(65, 70, 200);
                PreviouslyClicked = Clicked.Parent as Panel;
            }
            else if(sender.GetType().Name == "TextBox")
            {
                TextBox Clicked = sender as TextBox;
                Selected = int.Parse(Clicked.Name.Split('_')[3]);
                Clicked.Parent.BackColor = Color.FromArgb(65, 70, 200);
                PreviouslyClicked = Clicked.Parent as Panel;
            }
            Update_Buttons();
        }

        // delete selected user from the database and reload the user list
        private void Btn_User_Delete_Click(object sender, EventArgs e)
        {
            DialogResult UserAccept = MessageBox.Show("Are you sure you want to delete this", "Deleting Item", MessageBoxButtons.YesNo);
            if (UserAccept == DialogResult.Yes)
            {
                User.Delete_User(Selected);
                Update_User_List();
            }
        }

        // update buttons based on the clicked status
        private void Update_Buttons()
        {
            if(Selected != -1)
            {
                Btn_User_Edit.Enabled = true;
                Btn_User_Delete.Enabled = true;
                Btn_User_Edit.BackColor = Color.FromArgb(31, 31, 31);
                Btn_User_Delete.BackColor = Color.FromArgb(215, 0, 0); 
            }
            else
            {
                Btn_User_Edit.Enabled = false;
                Btn_User_Delete.Enabled = false;
                Btn_User_Edit.BackColor = Color.FromArgb(51,51,51);
                Btn_User_Delete.BackColor = Color.FromArgb(255, 60, 60);
            }
        }

        /// edit selected user details in the database by using user inserted 
        /// values for name and password
        private void Btn_User_Edit_Click(object sender, EventArgs e)
        {
            string Name;
            string Password;
            // Get UserName
            GetInput.Set_Values("Enter Name For User ", PreviouslyClicked.Controls[0].Text);
            GetInput.ShowDialog();
            if (!GetInput.Cancel)
            {
                Name = GetInput.Get_Value();
                // Get Password
                GetInput.Set_Values("Enter Password For User ", PreviouslyClicked.Controls[1].Text);
                GetInput.ShowDialog();
                if (!GetInput.Cancel)
                {
                    Password = GetInput.Get_Value();
                    if(Name != "" && Password != "")
                    {
                        User.Update_User(Selected, Name, Password);
                        Update_User_List();
                    }
                    else
                    {
                        MessageBox.Show("Name and Password Required", "Empty fields");
                    }
                }
            }
        }

        /// insert user to the database by using user inserted values for
        /// name and password
        private void Btn_User_Add_Click(object sender, EventArgs e)
        {
            string Name;
            string Password;
            // Get UserName
            GetInput.Set_Values("Enter Name For User", "");
            GetInput.ShowDialog();
            if (!GetInput.Cancel)
            {
                Name = GetInput.Get_Value();
                GetInput.Set_Values("Enter Password For " + Name, "");
                GetInput.ShowDialog();
                if (!GetInput.Cancel)
                {
                    Password = GetInput.Get_Value();
                    if(Name != "" && Password != "")
                    {
                        if(User.Is_UserName_Exist(Name))
                        {
                            MessageBox.Show("UserName Already Exist", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                        else
                        {
                            User.Insert_User(Name, Password);
                            Update_User_List();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Username and Password Required", "Empty Fields", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
        }

        /// update user list in the user loader panel by getting user
        /// list from the database
        private void Update_User_List()
        {
            PreviouslyClicked = new Panel();
            Selected = -1;
            Panel_User_Loader.Controls.Clear();
            List<UserStruct> Users = User.Retrieve_Users();
            foreach(UserStruct User in Users)
            {
                Insert_User(User.Id, User.Name, User.Password);
            }
            Update_Buttons();
        } 
    }
}
